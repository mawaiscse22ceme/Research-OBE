/**
 */
package ObeModel.impl;

import ObeModel.Activity;
import ObeModel.Mission;
import ObeModel.ObeModelPackage;
import ObeModel.PEO;
import ObeModel.Plo;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectResolvingEList;
import org.eclipse.emf.ecore.util.EObjectWithInverseResolvingEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>PEO</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link ObeModel.impl.PEOImpl#getPEOStatement <em>PEO Statement</em>}</li>
 *   <li>{@link ObeModel.impl.PEOImpl#getThreshold <em>Threshold</em>}</li>
 *   <li>{@link ObeModel.impl.PEOImpl#getAssesedby <em>Assesedby</em>}</li>
 *   <li>{@link ObeModel.impl.PEOImpl#getMission <em>Mission</em>}</li>
 *   <li>{@link ObeModel.impl.PEOImpl#getPlos <em>Plos</em>}</li>
 * </ul>
 *
 * @generated
 */
public class PEOImpl extends MinimalEObjectImpl.Container implements PEO {
	/**
	 * The default value of the '{@link #getPEOStatement() <em>PEO Statement</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPEOStatement()
	 * @generated
	 * @ordered
	 */
	protected static final String PEO_STATEMENT_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getPEOStatement() <em>PEO Statement</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPEOStatement()
	 * @generated
	 * @ordered
	 */
	protected String peoStatement = PEO_STATEMENT_EDEFAULT;

	/**
	 * The default value of the '{@link #getThreshold() <em>Threshold</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getThreshold()
	 * @generated
	 * @ordered
	 */
	protected static final int THRESHOLD_EDEFAULT = 0;

	/**
	 * The cached value of the '{@link #getThreshold() <em>Threshold</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getThreshold()
	 * @generated
	 * @ordered
	 */
	protected int threshold = THRESHOLD_EDEFAULT;

	/**
	 * The cached value of the '{@link #getAssesedby() <em>Assesedby</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAssesedby()
	 * @generated
	 * @ordered
	 */
	protected EList<Activity> assesedby;

	/**
	 * The cached value of the '{@link #getMission() <em>Mission</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getMission()
	 * @generated
	 * @ordered
	 */
	protected Mission mission;

	/**
	 * The cached value of the '{@link #getPlos() <em>Plos</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPlos()
	 * @generated
	 * @ordered
	 */
	protected EList<Plo> plos;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected PEOImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ObeModelPackage.Literals.PEO;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getPEOStatement() {
		return peoStatement;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setPEOStatement(String newPEOStatement) {
		String oldPEOStatement = peoStatement;
		peoStatement = newPEOStatement;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ObeModelPackage.PEO__PEO_STATEMENT, oldPEOStatement,
					peoStatement));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getThreshold() {
		return threshold;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setThreshold(int newThreshold) {
		int oldThreshold = threshold;
		threshold = newThreshold;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ObeModelPackage.PEO__THRESHOLD, oldThreshold,
					threshold));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Activity> getAssesedby() {
		if (assesedby == null) {
			assesedby = new EObjectResolvingEList<Activity>(Activity.class, this, ObeModelPackage.PEO__ASSESEDBY);
		}
		return assesedby;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Mission getMission() {
		if (mission != null && mission.eIsProxy()) {
			InternalEObject oldMission = (InternalEObject) mission;
			mission = (Mission) eResolveProxy(oldMission);
			if (mission != oldMission) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, ObeModelPackage.PEO__MISSION, oldMission,
							mission));
			}
		}
		return mission;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Mission basicGetMission() {
		return mission;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setMission(Mission newMission) {
		Mission oldMission = mission;
		mission = newMission;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ObeModelPackage.PEO__MISSION, oldMission, mission));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Plo> getPlos() {
		if (plos == null) {
			plos = new EObjectWithInverseResolvingEList<Plo>(Plo.class, this, ObeModelPackage.PEO__PLOS,
					ObeModelPackage.PLO__PEO);
		}
		return plos;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public NotificationChain eInverseAdd(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case ObeModelPackage.PEO__PLOS:
			return ((InternalEList<InternalEObject>) (InternalEList<?>) getPlos()).basicAdd(otherEnd, msgs);
		}
		return super.eInverseAdd(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case ObeModelPackage.PEO__PLOS:
			return ((InternalEList<?>) getPlos()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case ObeModelPackage.PEO__PEO_STATEMENT:
			return getPEOStatement();
		case ObeModelPackage.PEO__THRESHOLD:
			return getThreshold();
		case ObeModelPackage.PEO__ASSESEDBY:
			return getAssesedby();
		case ObeModelPackage.PEO__MISSION:
			if (resolve)
				return getMission();
			return basicGetMission();
		case ObeModelPackage.PEO__PLOS:
			return getPlos();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case ObeModelPackage.PEO__PEO_STATEMENT:
			setPEOStatement((String) newValue);
			return;
		case ObeModelPackage.PEO__THRESHOLD:
			setThreshold((Integer) newValue);
			return;
		case ObeModelPackage.PEO__ASSESEDBY:
			getAssesedby().clear();
			getAssesedby().addAll((Collection<? extends Activity>) newValue);
			return;
		case ObeModelPackage.PEO__MISSION:
			setMission((Mission) newValue);
			return;
		case ObeModelPackage.PEO__PLOS:
			getPlos().clear();
			getPlos().addAll((Collection<? extends Plo>) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case ObeModelPackage.PEO__PEO_STATEMENT:
			setPEOStatement(PEO_STATEMENT_EDEFAULT);
			return;
		case ObeModelPackage.PEO__THRESHOLD:
			setThreshold(THRESHOLD_EDEFAULT);
			return;
		case ObeModelPackage.PEO__ASSESEDBY:
			getAssesedby().clear();
			return;
		case ObeModelPackage.PEO__MISSION:
			setMission((Mission) null);
			return;
		case ObeModelPackage.PEO__PLOS:
			getPlos().clear();
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case ObeModelPackage.PEO__PEO_STATEMENT:
			return PEO_STATEMENT_EDEFAULT == null ? peoStatement != null : !PEO_STATEMENT_EDEFAULT.equals(peoStatement);
		case ObeModelPackage.PEO__THRESHOLD:
			return threshold != THRESHOLD_EDEFAULT;
		case ObeModelPackage.PEO__ASSESEDBY:
			return assesedby != null && !assesedby.isEmpty();
		case ObeModelPackage.PEO__MISSION:
			return mission != null;
		case ObeModelPackage.PEO__PLOS:
			return plos != null && !plos.isEmpty();
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (PEOStatement: ");
		result.append(peoStatement);
		result.append(", threshold: ");
		result.append(threshold);
		result.append(')');
		return result.toString();
	}

} //PEOImpl
